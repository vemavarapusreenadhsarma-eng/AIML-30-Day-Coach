package com.example.aimlcoach;
import android.app.*;import android.content.*;import android.os.Build;import java.util.*;
public class Scheduler {
 public static void scheduleAll(Context c){schedule(c,"morning");schedule(c,"evening");}
 public static void schedule(Context c,String slot){int hour=slot.equals("morning")?7:20,minute=slot.equals("morning")?0:30;
 Calendar when=Calendar.getInstance();when.set(Calendar.HOUR_OF_DAY,hour);when.set(Calendar.MINUTE,minute);when.set(Calendar.SECOND,0);when.set(Calendar.MILLISECOND,0);
 if(when.getTimeInMillis()<=System.currentTimeMillis())when.add(Calendar.DAY_OF_YEAR,1);
 Intent i=new Intent(c,ReminderReceiver.class).putExtra("slot",slot);
 PendingIntent pi=PendingIntent.getBroadcast(c,slot.equals("morning")?11:12,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
 if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when.getTimeInMillis(),pi);
 else if(Build.VERSION.SDK_INT<31)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when.getTimeInMillis(),pi);
 else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when.getTimeInMillis(),pi);
 }
}
