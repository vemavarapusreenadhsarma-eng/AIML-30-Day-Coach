package com.example.aimlcoach;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {public void onReceive(Context c,Intent i){Scheduler.scheduleAll(c);}}
