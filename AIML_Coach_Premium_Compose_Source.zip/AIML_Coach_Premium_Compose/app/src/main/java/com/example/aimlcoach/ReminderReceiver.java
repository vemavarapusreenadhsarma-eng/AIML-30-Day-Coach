package com.example.aimlcoach;
import android.app.*;import android.content.*;import android.os.Build;
public class ReminderReceiver extends android.content.BroadcastReceiver {
 public void onReceive(Context c,Intent i){String slot=i.getStringExtra("slot");if(slot==null)slot="morning";
  Scheduler.schedule(c,slot);
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  String channel="study";nm.createNotificationChannel(new NotificationChannel(channel,"Study reminders",NotificationManager.IMPORTANCE_HIGH));
  Intent open=new Intent(c,MainActivity.class).putExtra("slot",slot).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
  PendingIntent pi=PendingIntent.getActivity(c,slot.equals("morning")?1:2,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(c,channel).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(slot.equals("morning")?"7:00 AM — AI/ML morning lesson":"8:30 PM — AI/ML evening practice").setContentText("Your 30-minute focused learning session is ready. Tap to start.").setContentIntent(pi).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).build();
  try{nm.notify(slot.equals("morning")?11:12,n);}catch(SecurityException ignored){}
 }
}
