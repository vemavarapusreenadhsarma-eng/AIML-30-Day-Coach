package com.example.aimlcoach

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import kotlin.math.min

private val Ink=Color(0xFF24324B)
private val Muted=Color(0xFF6C7990)
private val Lavender=Color(0xFF8C77C7)
private val Lilac=Color(0xFFF0EAFC)
private val Teal=Color(0xFF3F9B96)
private val Mint=Color(0xFFE5F5F0)
private val Back=Color(0xFFF8F9FE)
private val Sky=Color(0xFFE9F1FC)
private val Peach=Color(0xFFFFF1E9)
private val White=Color.White

class MainActivity:ComponentActivity() {
 private val notificationPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  Scheduler.scheduleAll(this)
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
  val data=JSONArray(assets.open("lessons.json").bufferedReader().use{it.readText()})
  setContent { MaterialTheme(colorScheme=lightColorScheme(primary=Lavender,secondary=Teal,background=Back,surface=White,onSurface=Ink)) { CoachApp(this,data) } }
 }
}

@Composable private fun CoachApp(context:Context,lessons:JSONArray){
 val prefs=remember{context.getSharedPreferences("coach_v4",Context.MODE_PRIVATE)}
 var tab by remember { mutableStateOf(0) }
 var day by remember { mutableIntStateOf(prefs.getInt("day",1).coerceIn(1,30)) }
 var slot by remember { mutableStateOf("morning") }
 var quizSelection by remember(day){mutableIntStateOf(-1)}
 var quizSubmitted by remember(day){mutableStateOf(false)}
 var elapsed by remember(day,slot){mutableLongStateOf(prefs.getLong("seconds_${day}_$slot",0L))}
 var running by remember{mutableStateOf(false)}
 var minutesToday by remember{mutableIntStateOf(prefs.getInt("total_minutes",0))}
 var xp by remember{mutableIntStateOf(prefs.getInt("xp",0))}
 var completed by remember{mutableIntStateOf(prefs.getInt("completed",0))}
 val lesson=remember(day){lessons.getJSONObject(day-1)}
 LaunchedEffect(running,day,slot){while(running && elapsed<1800){delay(1000);elapsed++;prefs.edit().putLong("seconds_${day}_$slot",elapsed).apply(); if(elapsed%60L==0L){minutesToday++;prefs.edit().putInt("total_minutes",minutesToday).apply()}};if(elapsed>=1800L)running=false}
 fun completeIfReady(){if(elapsed>=1800L && quizSubmitted && quizSelection==lesson.optInt("answer",0)){
  val key="done_${day}_$slot";if(!prefs.getBoolean(key,false)){prefs.edit().putBoolean(key,true).apply();xp+=25;prefs.edit().putInt("xp",xp).apply()}
  if(prefs.getBoolean("done_${day}_morning",false)&&prefs.getBoolean("done_${day}_evening",false)&&!prefs.getBoolean("day_done_$day",false)){
    completed++;prefs.edit().putBoolean("day_done_$day",true).putInt("completed",completed).apply()
    if(day<30){day++;prefs.edit().putInt("day",day).apply()}
  }
 }}
 BackHandler(tab!=0){running=false;tab=0}
 Scaffold(containerColor=Back,bottomBar={ NavigationBar(containerColor=White,tonalElevation=4.dp){
  val icons=listOf(Icons.Default.Home,Icons.Default.AutoStories,Icons.Default.Bolt,Icons.Default.DonutLarge,Icons.Default.MenuBook)
  val names=listOf("Home","Learn","Practice","Progress","Roadmap")
  names.forEachIndexed{index,name->NavigationBarItem(selected=tab==index,onClick={running=false;tab=index},icon={Icon(icons[index],null,modifier=Modifier.size(22.dp))},label={Text(name,fontSize=10.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Lavender,selectedTextColor=Lavender,indicatorColor=Lilac,unselectedIconColor=Muted))}
 }}) { inner ->
  Column(Modifier.fillMaxSize().padding(inner)){
   when(tab){
    0 -> HomeScreen(day,completed,xp,minutesToday,lesson.optString("title"),onLearn={tab=1},onPractice={tab=2},onRoadmap={tab=4})
    1 -> LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
      item{PageHeading("Today's lesson","DAY $day • FOUNDATION TRACK")}
      item{HeroPanel("Understand it. Then use it.",lesson.optString("title"),"✦",Lilac)}
      item{SectionHeading("The big idea")}
      item{TextCard(lesson.optString("concept"),Mint)}
      item{SectionHeading("Let's go deeper")}
      item{TextCard(lesson.optString("deepDive",lesson.optString("concept")),White)}
      item{SectionHeading("Try it yourself")}
      item{TextCard(lesson.optString("exercise"),Peach)}
      item{Button(onClick={tab=2},modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(18.dp)){Text("Start interactive practice  →",fontWeight=FontWeight.Bold)}}
    }
    2 -> LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
      item{PageHeading("Practice studio","LEARN BY DOING")}
      item{SectionHeading("Choose your session")}
      item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
        listOf("morning" to "☀ Morning","evening" to "☾ Evening").forEach{(value,label)->FilterChip(selected=slot==value,onClick={running=false;slot=value;quizSelection=-1;quizSubmitted=false;elapsed=prefs.getLong("seconds_${day}_$slot",0L)},label={Text(label)})}
      }}
      item{Card(shape=RoundedCornerShape(26.dp),colors=CardDefaults.cardColors(containerColor=White),modifier=Modifier.fillMaxWidth()){
        Column(Modifier.fillMaxWidth().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(12.dp)){
          Text("FOCUS SESSION",color=Muted,fontSize=12.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp)
          Box(Modifier.size(196.dp),contentAlignment=Alignment.Center){CircularProgressIndicator(progress={elapsed.toFloat()/1800f},modifier=Modifier.fillMaxSize(),strokeWidth=12.dp,color=Teal,trackColor=Mint,strokeCap=StrokeCap.Round)
            Column(horizontalAlignment=Alignment.CenterHorizontally){Text("%02d:%02d".format((1800-elapsed).coerceAtLeast(0)/60,(1800-elapsed).coerceAtLeast(0)%60),fontSize=38.sp,fontWeight=FontWeight.Bold,color=Ink);Text("30 MIN GOAL",fontSize=11.sp,color=Muted)}}
          Text("Time counts while this screen is active. You can always leave safely.",fontSize=12.sp,color=Muted,textAlign=TextAlign.Center)
          Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){
            Button(onClick={running=!running},enabled=elapsed<1800,shape=RoundedCornerShape(16.dp)){Icon(if(running)Icons.Default.Pause else Icons.Default.PlayArrow,null);Spacer(Modifier.width(4.dp));Text(if(running)"Pause" else "Start focus")}
            OutlinedButton(onClick={running=false;tab=0},shape=RoundedCornerShape(16.dp)){Text("Exit")}
          }
        }
      }}
      item{SectionHeading("Your challenge")}
      item{TextCard(lesson.optString("exercise"),Mint)}
      item{SectionHeading("Knowledge check")}
      item{Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=White)){
        Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
          Text(lesson.optString("question"),fontWeight=FontWeight.Bold,fontSize=17.sp,color=Ink)
          val choices=lesson.optJSONArray("choices")?:JSONArray()
          for(i in 0 until choices.length()){
            val selected=quizSelection==i
            Surface(onClick={if(!quizSubmitted) quizSelection=i},color=if(selected)Lilac else Back,shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,if(selected)Lavender else Color(0xFFE7E9F0))){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(if(selected)Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,null,tint=if(selected)Lavender else Muted);Spacer(Modifier.width(10.dp));Text(choices.optString(i),color=Ink)}}
          }
          if(quizSubmitted){Text(if(quizSelection==lesson.optInt("answer",0))"✓ Great work! You've understood the idea." else "Not quite. Review the explanation and try again.",color=if(quizSelection==lesson.optInt("answer",0))Teal else Color(0xFFC16B55),fontWeight=FontWeight.SemiBold)}
          Button(enabled=quizSelection>=0,onClick={quizSubmitted=true;completeIfReady()},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text("Check answer")}
          if(quizSubmitted&&quizSelection!=lesson.optInt("answer",0)){TextButton(onClick={quizSubmitted=false;quizSelection=-1}){Text("Try again")}}
          if(elapsed<1800)Text("Complete 30 focused minutes and pass the quiz to finish this session.",fontSize=12.sp,color=Muted)
          else if(quizSubmitted&&quizSelection==lesson.optInt("answer",0))Text("Session completed! +25 XP",color=Teal,fontWeight=FontWeight.Bold)
        }
      }}
    }
    3 -> LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
      item{PageHeading("Your progress","SMALL STEPS, BIG GROWTH")}
      item{HeroPanel("You're building momentum","Keep showing up for your two daily sessions.","✦",Mint)}
      item{Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){StatCard("$completed/30","Days done",Modifier.weight(1f));StatCard("$xp","Total XP",Modifier.weight(1f))}}
      item{StatCard("$minutesToday min","Focused study time",Modifier.fillMaxWidth())}
      item{SectionHeading("Learning journey")}
      item{LinearProgressIndicator(progress={completed/30f},modifier=Modifier.fillMaxWidth().height(12.dp).clip(CircleShape),color=Teal,trackColor=Mint)}
      item{Text("Finish both morning and evening sessions to complete each day.",color=Muted,fontSize=13.sp)}
    }
    else -> LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
      item{PageHeading("Your 30-day path","FROM BEGINNER TO AI AGENT BUILDER")}
      items((1..30).toList()){index->val obj=lessons.getJSONObject(index-1);val done=index<=completed
        Surface(onClick={day=index;running=false;tab=1},shape=RoundedCornerShape(19.dp),color=if(index==day)Lilac else White,shadowElevation=1.dp){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(44.dp).background(if(done)Mint else Sky,CircleShape),contentAlignment=Alignment.Center){Text(if(done)"✓" else "$index",color=if(done)Teal else Lavender,fontWeight=FontWeight.Bold)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("DAY $index",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold);Text(obj.optString("title"),fontWeight=FontWeight.SemiBold,color=Ink,fontSize=14.sp)};Icon(Icons.Default.ChevronRight,null,tint=Muted)}}
      }
    }
   }
  }
 }
}

@Composable private fun HomeScreen(day:Int,completed:Int,xp:Int,minutes:Int,title:String,onLearn:()->Unit,onPractice:()->Unit,onRoadmap:()->Unit){
 LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(17.dp)){
  item{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("GOOD TO SEE YOU ✨",color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp);Text("Your learning space",fontSize=25.sp,color=Ink,fontWeight=FontWeight.Bold)};Box(Modifier.size(46.dp).background(Lilac,CircleShape),contentAlignment=Alignment.Center){Icon(Icons.Default.School,null,tint=Lavender)}}}
  item{Card(shape=RoundedCornerShape(28.dp),colors=CardDefaults.cardColors(containerColor=Color.Transparent),modifier=Modifier.fillMaxWidth()){
   Column(Modifier.background(Brush.linearGradient(listOf(Color(0xFFE8E2FC),Color(0xFFE0F4F1),Color(0xFFECF2FE)))).padding(23.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
    Text("✦ YOUR 30-DAY JOURNEY",color=Lavender,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp)
    Text("Big ideas start with small steps.",color=Ink,fontSize=26.sp,lineHeight=31.sp,fontWeight=FontWeight.Bold)
    Text("Discover AI, build confidence, and create your first intelligent agent.",color=Muted,fontSize=14.sp,lineHeight=21.sp)
    Button(onClick=onLearn,shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Lavender)){Text("Continue Day $day  →",fontWeight=FontWeight.Bold)}
   }
  }}
  item{Row(horizontalArrangement=Arrangement.spacedBy(11.dp)){StatCard("$completed/30","Days complete",Modifier.weight(1f));StatCard("$xp ✦","XP earned",Modifier.weight(1f));StatCard("$minutes","Study mins",Modifier.weight(1f))}}
  item{SectionHeading("Today's learning")}
  item{Card(onClick=onLearn,shape=RoundedCornerShape(23.dp),colors=CardDefaults.cardColors(containerColor=White)){
   Row(Modifier.fillMaxWidth().padding(17.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(56.dp).background(Lilac,RoundedCornerShape(17.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.Psychology,null,tint=Lavender,modifier=Modifier.size(29.dp))};Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text("DAY $day • LESSON",color=Lavender,fontSize=11.sp,fontWeight=FontWeight.Bold);Text(title,color=Ink,fontSize=16.sp,fontWeight=FontWeight.Bold)};Icon(Icons.Default.ArrowForwardIos,null,tint=Lavender,modifier=Modifier.size(17.dp))}
  }}
  item{SectionHeading("Your daily sessions")}
  item{Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){SessionTile("☀","7:00 AM","Morning lesson",Lilac,Modifier.weight(1f),onPractice);SessionTile("☾","8:30 PM","Evening practice",Mint,Modifier.weight(1f),onPractice)}}
  item{Surface(onClick=onRoadmap,shape=RoundedCornerShape(20.dp),color=Sky){Row(Modifier.fillMaxWidth().padding(17.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Route,null,tint=Lavender);Spacer(Modifier.width(10.dp));Text("Explore your 30-day roadmap",Modifier.weight(1f),fontWeight=FontWeight.Bold,color=Ink);Icon(Icons.Default.ChevronRight,null,tint=Lavender)}}}
 }
}
@Composable private fun PageHeading(title:String,eyebrow:String){Column(verticalArrangement=Arrangement.spacedBy(5.dp)){Text(eyebrow,color=Lavender,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp);Text(title,color=Ink,fontWeight=FontWeight.Bold,fontSize=27.sp)}}
@Composable private fun SectionHeading(title:String){Text(title,color=Ink,fontWeight=FontWeight.Bold,fontSize=19.sp)}
@Composable private fun TextCard(text:String,color:Color){Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=color),modifier=Modifier.fillMaxWidth()){Text(text,modifier=Modifier.padding(20.dp),fontSize=15.sp,lineHeight=24.sp,color=Ink)}}
@Composable private fun HeroPanel(eyebrow:String,title:String,symbol:String,color:Color){Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=color)){Row(Modifier.fillMaxWidth().padding(20.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(eyebrow,color=Lavender,fontSize=12.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp));Text(title,color=Ink,fontSize=22.sp,fontWeight=FontWeight.Bold,lineHeight=28.sp)};Text(symbol,fontSize=44.sp,color=Lavender)}}}
@Composable private fun StatCard(value:String,label:String,modifier:Modifier=Modifier){Card(modifier=modifier,shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=White)){Column(Modifier.padding(15.dp)){Text(value,color=Ink,fontSize=21.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(5.dp));Text(label,color=Muted,fontSize=11.sp)}}}
@Composable private fun SessionTile(symbol:String,time:String,title:String,color:Color,modifier:Modifier,onClick:()->Unit){Card(onClick=onClick,modifier=modifier,shape=RoundedCornerShape(21.dp),colors=CardDefaults.cardColors(containerColor=color)){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text(symbol,fontSize=28.sp,color=Lavender);Text(time,fontWeight=FontWeight.Bold,color=Ink,fontSize=17.sp);Text(title,color=Muted,fontSize=12.sp);Text("Start →",color=Teal,fontWeight=FontWeight.Bold,fontSize=12.sp)}}}
