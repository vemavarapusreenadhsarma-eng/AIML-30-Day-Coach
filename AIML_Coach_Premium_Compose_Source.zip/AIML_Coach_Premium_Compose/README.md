# AI/ML Coach — Premium Compose Edition

This is a **real Jetpack Compose / Material 3 UI rebuild**, not a recoloring of the original Java screen. Includes responsive dashboard, 5-tab bottom navigation, course lesson pages, 30-day roadmap, practice quiz, circular 30-minute focus timer, XP, and persisted progress. Soft pearl, lavender, mint and blue theme.

## Android-phone-only GitHub build

1. Download `AIML_Coach_Premium_Compose_Source.zip`.
2. In the existing GitHub repository, **delete any previous root-level ZIPs**, then upload this ZIP to the **repository root**, not `.github/workflows`.
3. Your existing workflow may choose an arbitrary ZIP. To avoid this, replace `.github/workflows/main.yml` with the `main.yml` in this package (also provided separately). This workflow explicitly selects `AIML_Coach_Premium_Compose_Source.zip`.
4. Commit. Go to Actions, open the latest run. Download artifact `AIML-Coach-Premium-APK`, extract and install the debug APK.

The ZIP includes its own `.github/workflows/main.yml` for a new repository, but uploading a ZIP alone **does not install the workflow inside the ZIP**. You must update the repository's workflow once, or extract and upload all files.

## Features and limitations

- 30 days of offline lesson material in `app/src/main/assets/lessons.json`.
- Morning and evening reminder notifications scheduled at 07:00 and 20:30, subject to Android notification and alarm policies.
- Foreground focus timer (30 minutes per session), persisted locally; user may always leave safely.
- Quiz and completion state saved in SharedPreferences. Each session requires 30 minutes plus correct answer; complete both sessions to finish a day.
- **No forced overlay or app blocking**. Modern Android prevents ordinary apps from preventing exit.
- The new design uses built-in vector icons and Compose graphics, not copyrighted third-party app assets.
- This source has not been compiled or tested on a device here. A GitHub build is necessary to confirm compilation and runtime behavior.

## Build locally

JDK 17, Android SDK platform 35, Gradle 8.9. `gradle :app:assembleDebug`.
