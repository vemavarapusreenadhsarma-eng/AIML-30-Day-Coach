# AI/ML 30-Day Coach — Android source project

Native Java Android app. Calm midnight navy / sage teal / soft lavender UI, no third-party libraries or backend required.

## Features
- 30 beginner-friendly AI/ML lessons in `app/src/main/assets/lessons.json`.
- Morning 07:00 concept session and evening 20:30 practice session, 30 minutes each.
- 30-minute foreground focus timer per session, persisted locally. A correct quiz answer **and** 30 minutes are needed to mark a session complete.
- Daily scheduled notifications with rescheduling after reboot. Exact alarms used when Android permits; otherwise inexact alarms.
- 30-day roadmap and progress. No account or network required.
- Manual Exit/Pause and normal Android navigation/emergency access remain available.

## Build APK in Android Studio
1. Install Android Studio (recent version with JDK 17 and Android SDK 35).
2. Extract this ZIP, choose **Open** and select the `AIML30DayCoach` folder.
3. Allow Android Studio to download Gradle plugin 8.7.3 and sync. If prompted, install SDK Platform 35.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy to your Android phone and install (allow installs from this source when prompted).
7. Open the app, grant notification permission, and allow exact alarms in Android settings if desired.

## Important Android limitations
- Android does not allow a normal app to forcibly stay above all other apps or block Home/Recents/emergency access. This app **does not** use overlays, kiosk/device-owner mode or accessibility hacks.
- Android generally does not allow an app to launch an activity automatically from the background at alarm time. Notifications prompt you to open the session.
- Alarm delivery can be delayed by Doze, OEM battery optimizations and missing exact-alarm permission. Grant permissions and exempt from battery restrictions if needed.
- The app measures foreground screen time, not verified attention. The quiz adds a simple learning check.
- Days advance by calendar day from first launch. Past days are previewable, but timed sessions target the current day.
- This source project was generated without an Android SDK/Gradle build environment, so it has not been compiled or device-tested. Verify and test in Android Studio.

## Editing the content or UI
- Change the topics, explanations, exercises, and quiz options in `lessons.json` (30 records).
- Change color constants `BG`, `CARD`, `BLUE`, `PURPLE` in `MainActivity.java`.
- Change times in `Scheduler.java` and notification wording in `ReminderReceiver.java`.

## Privacy
All progress stays in local SharedPreferences. No location, microphone, contact, or internet permission is requested.

## Calm UI and expanded lesson edition
- Soft navy, slate, sage and lavender colors replace saturated neon gradients.
- Cards have subtle elevation, comfortable spacing and scrollbars are hidden for a calmer reading experience.
- Each of the 30 lessons now includes an extended explanation, practical example and step-by-step exercise.
- The new content is a beginner-friendly starter curriculum, not externally peer-reviewed courseware or a substitute for hands-on instructor feedback.
- Verify readability, performance, accessibility and notification delivery on your actual phone.
