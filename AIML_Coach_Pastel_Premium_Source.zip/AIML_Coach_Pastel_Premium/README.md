# AI/ML Coach — Pastel Premium Android edition

This source project replaces the old dark handwritten-style interface with a consistent pearl-white, lavender and mint-teal UI. It includes 30 beginner lesson records, morning and evening practice, quiz checks, foreground study time, saved progress, and reminder scheduling at 07:00 and 20:30.

## Build using only an Android phone

1. Download `AIML_Coach_Pastel_Premium_Source.zip` from the conversation.
2. In your GitHub repository, upload this ZIP to the root of the repository (you can leave the previous ZIP, but delete the previous one to avoid the workflow selecting it).
3. Keep your *working* `.github/workflows/main.yml` from the previous successful build. It searches for a ZIP in the repository root, extracts it and builds the project. This ZIP also includes a copy of that working workflow for new repositories.
4. Commit the ZIP upload. Open Actions and select the newest run. When it succeeds, download the `AIML-Coach-Android-APK` artifact, extract it and install the `.apk`.

**Note:** If your existing workflow chooses the first ZIP alphabetically, delete the old source ZIP before committing the new one. Android may require uninstalling the previous app before installing a differently signed build; uninstalling deletes local app progress, so consider backing it up first. This package was statically checked, but has not been compiled or device-tested here.

## App behavior

- Session completion requires 30 minutes of foreground learning plus a correct quiz answer.
- Reminder notifications may depend on notification and exact-alarm permissions, and device battery policies.
- Emergency access, Home navigation and a manual exit are never blocked.
- The UI is constructed programmatically in `app/src/main/java/com/example/aimlcoach/MainActivity.java`.
- Curriculum data is stored in `app/src/main/assets/lessons.json`.

## Build in Android Studio

Open the project directory and run `gradle :app:assembleDebug` with JDK 17 and a compatible Android SDK/Gradle setup. The GitHub workflow installs Gradle 8.9.
